//Vishalsingh Hajeri
//data structures and Algorithm
//Filecreation
#include <iostream>
#include <fstream>


using namespace std;

void insertionSort(int a[], int N);

void print(int *v, int n);

int main(int argc, const char * argv[]) {

	

	int a[32768], temp, i = 0;

	ifstream myfile;
	myfile.open("q4.txt");

	if (myfile.is_open()) {

		while (myfile >> temp) {

			a[i] = temp;
			i++;
		}

	}

	insertionSort(a, i);
	print(a, i);

	ofstream output;
	output.open("out.txt");
	

	for (int j = 0; j < i; j++) {
		output << a[j] << endl;
	}
	output.close();


	return 0;
}

void print(int v[], int n)
{

	for (int i = 0; i < n; i++)
	{

		cout << "\t" << v[i];

	}

}

void insertionSort(int a[], int N)
{
	int temp;
	for (int i = 1; i < N; i++)
	{
		for (int j = i; j > 0 && a[j] < a[j - 1]; j--) {

			temp = a[j];
			a[j] = a[j - 1];
			a[j - 1] = temp;
		}
	}
}
