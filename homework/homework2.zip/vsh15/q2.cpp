//Vishalsingh Hajeri
//Data Structure and Algorithm
//03/01/2016

#include<iostream>
#include<fstream>
#include<iomanip>
#include<string>
#include<vector>
#include<ctime>
#include<math.h>
#include<cmath>
using namespace std;

void print(int *v, int n);
void insertionsort(int *v, int len);
void shellsort(int *v, int len);
int count = 0;

int main(int argc, char* argv[]){

	int array[32768];
	int temp, n;
	string file;
	int z = 0;
	
	//cout << "Please Enter the path of your data file OR you can keep your data file in the program folder and enter just the file name!" << endl;
	cin >> file;

	//cout << "Please enter file size" << endl;
	//cin >> n;
	
	clock_t start = clock();//counter starts to measure execution time
	ifstream input(file);
	
	while (input >> temp)
	{

		array[z] = temp;
		z++;

	}
	n = z;

	//print(array,n);
	//insertionsort(array, n);
	shellsort(array, n);
	//cout << "\n\n\n";
	print(array, n);
	clock_t end = clock();
	cout << "\ncount = " << ::count;
	cout << "\nexecution time : " << end - start << endl;
	

	//Writing answer to out.tx
	ofstream output;
	output.open("out.txt");
	output << ::count << endl;

	for (int i = 0; i < n; i++) {
		output << array[i] << endl;
	}
	output.close();
	//system("pause");
	return 0;
}


void print(int v[], int n)
{

	for (int i = 0; i < n; i++)
	{

		cout << "\t" << v[i];

	}

}

void shellsort(int *a, int len) {
	int x, h,j,temp,h_temp;
	x = 3;
	while (x > 0) {
		h = (pow(2, x) - 1);
		h_temp = 0;
		while (h_temp < h) {
					
			for (int i = h_temp; i < len; i += h)
			{

				j = i;
				//if((j-h)>=0 && a[j]>a[j-h])
				//::count++;
				
				for (int j = i; (j - h) >= 0; j -= h)
				//while ((j-h) >= 0 &&( a[j] < a[j - h]))
				{
					::count++;

					if (a[j] < a[j - h])
					{

						temp = a[j];
						a[j] = a[j - h];
						a[j - h] = temp;
						//	j -= h;
					}

					else
						break;
				}

			}
			h_temp++;
		}
		x--;

	}

}

void insertionsort(int *a,int len)
{
	int j,temp;
	for (int i = 0; i < len; i++)
	{
		j = i;
		if(j!=0 && a[j]>a[j-1])
		::count++;

		while (j > 0 && a[j] < a[j - 1])
		{
			::count++;
			temp = a[j];
			a[j] = a[j - 1];
			a[j - 1] = temp;
			j--;

		}

	}

}







