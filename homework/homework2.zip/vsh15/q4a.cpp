//Vishalsingh Hajeri
//data structures and Algorithm
//Filecreation
#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, const char * argv[]) {

	int x1 = 1024;
	int x2 = x1 + 2048;
	int x3 = x2 + 4096;
	int	x4 = x3 + 1024;
	int arr[8192];

	for (int i = 0; i < 8192; i++)
	{
		if (i < x1)
			arr[i] = 1;

		else if (i >= x1 && i < x2)
			arr[i] = 11;

		else if (i >= x2 && i < x3)
			arr[i] = 111;

		else if (i >= x3 && i < x4)
			arr[i] = 1111;

	}
	
	ofstream myfile;
	myfile.open("q4.txt");

	if (myfile.is_open()) {

		for (int i = 0; i < x4; i++) {
			myfile << arr[i] << endl;
			cout << arr[i] <<" ";
		}
	}
	else cout << "Unable to open file" << endl;



	return 0;
}