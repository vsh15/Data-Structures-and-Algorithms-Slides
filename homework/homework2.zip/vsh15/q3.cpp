//Vishalsingh Hajeri
//Data Structure and Algorithm
//Kendall-tau

#include<iostream>
#include<fstream>
#include<iomanip>
#include<string>
#include<vector>
#include<ctime>

using namespace std;

void print(int *v, int n);
void sort(int *v, int low, int high);
int count = 0;
int min(int, int);

int main(int argc, char* argv[]){

	int array[32768];
	int temp, n;
	string file;
	int z = 0;

	//cout << "Please Enter the path of your data file OR you can keep your data file in the program folder and enter just the file name!" << endl;
	cin >> file;

	

	clock_t start = clock();//counter starts to measure execution time
	ifstream input(file);

	while (input >> temp)
	{

		array[z] = temp;
		z++;

	}

n = z;

	//print(array,n);
	sort(array, 0, n);

	//print(array, n);
	clock_t end = clock();
	cout <<  ::count<<endl;
	//cout << "\nexecution time : " << end - start << endl;
	ofstream output;

	output.open("out.txt");
	output << ::count;
	output.close();
	
	//system("pause");

	return 0;
}


void print(int v[], int n)
{

	for (int i = 0; i < n; i++)
	{

		cout << "\t" << v[i];

	}

}
void merge(int *a, int low, int mid, int high) {

	int i, j, k, aux[32768];
	i = low;
	k = low;
	j = mid + 1;

	//if (a[mid] < a[mid + 1])
	//return;

	while (i <= mid && j <= high)
	{
		if (a[i] < a[j])
		{
			
			aux[k] = a[i];
			k++;
			i++;
		}
		else
		{
			::count +=   (mid+1 - i);
			aux[k] = a[j];
			k++;
			j++;
		}
	}

	while (i <= mid)
	{
		
		aux[k] = a[i];
		k++;
		i++;
	}
	while (j <= high)
	{
		aux[k] = a[j];
		k++;
		j++;
	}


	for (i = low; i < k; i++)
	{
		a[i] = aux[i];
	}


}

void sort(int *a, int low, int high) {

	for (int size = 1; size < high; size = size * 2)
	{
		for (int lo = 0; lo < high - size; lo += size + size)
		{
			merge(a, lo, lo + size - 1, min((lo + size + size - 1), high));
		}


	}
}
int min(int x, int y) {


	if (x < y)
		return x;
	else return y;

}