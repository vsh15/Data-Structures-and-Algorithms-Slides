//Vishalsingh Hajeri
//Data Structure and Algorithm
//Top-down Approach Merge sort

#include<iostream>
#include<fstream>
#include<iomanip>
#include<string>
#include<vector>
#include<ctime>
using namespace std;

void print(int *v,int n);
void sort(int *v,int low,int high);
int count = 0;

int main(int argc, char* argv[]){
		
	int array[32768];
	int temp,n;
	string file;
	int z = 0;

	//cout << "Please Enter the path of your data file OR you can keep your data file in the program folder and enter just the file name!" << endl;
	cin >> file;

	//cout << "Please enter file size" << endl;
	//cin >> n;

	clock_t start = clock();//counter starts to measure execution time
	ifstream input(file);

	while (input >> temp)
	{

		array[z] = temp;
		z++;

	}

	n = z;
	//print(array,n);
	sort(array, 0, n-1);
//	cout << "\n\n\n";
	//print(array, n);
	clock_t end = clock();
	cout << ::count<<endl;
	//cout << "\nexecution time : " << end - start << endl;
	
	
	//Writing answer to out.tx
	ofstream output;
	output.open("out.txt");
	output << ::count << endl;

	for (int i = 0; i < n; i++) {
		output << array[i] << endl;
	}
	output.close();

	//system("pause");
	return 0;
}


void print(int v[],int n)
{

	for (int i = 0; i < n; i++)
	{

		cout << "\t" << v[i];

	}

}
void merge(int *a, int low,int mid, int high){

	int i, j, k, aux[32768];
	i = low;
	k = low;
	j = mid + 1;
	while (i <= mid && j <= high)
	{
		if (a[i] < a[j])
		{	
			::count++;
			aux[k] = a[i];
			k++;
			i++;
		}
		else
		{
			::count++;
			aux[k] = a[j];
			k++;
			j++;
		}
	}
	while (i <= mid)
	{
		aux[k] = a[i];
		k++;
		i++;
	}
	while (j <= high)
	{
		aux[k] = a[j];
		k++;
		j++;
	}

	
	for (i = low; i < k; i++)
	{
		a[i] = aux[i];
	}

	
}

void sort(int *a,int low,int high) {

	if (high <= low)
		return;

	else
	{
		int mid;
		mid = low + ((high - low) / 2);

		sort(a, low, mid);
		sort(a, mid + 1, high);
		merge(a, low, mid, high);
	}


}