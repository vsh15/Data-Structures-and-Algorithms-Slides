//Vishalsingh Hajeri
//Data Structure and Algorithm
//02/09/2016

#include<iostream>
#include<fstream>
#include<iomanip>
#include<string>
#include<vector>
#include<ctime>

int count = 0;
bool connection(int, int, std::vector<int>);
int checkroot(int, std::vector<int>);
void main() {
	clock_t start = clock();
	std::vector<int> v;
	int p, q;


	std::cout << "Assumption is made that maximum input number in your data sample is 8192" << std::endl;
	for (int i = 0; i <8192; i++)
	{
		v.push_back(i);
	}
	std::cout << std::endl;


	std::string file;
	std::cout << "Please Enter the path of your data file\n" << "\t OR\n" << " You can keep your data file in the program folder and enter just the file name!" << std::endl;
	std::cin >> file;


	std::ifstream input(file);

	while (input >> p >> q)
	{
		int temp1 = checkroot(p, v);
		int temp2 = checkroot(q, v);

		if (temp1 != temp2)
		{
			std::cout << p << "-" << q << std::endl;
			v[temp1] = temp2;
		}

		else {
			count++;
			std::cout << p << " & " << q << " are already connected" << std::endl;
		}
	}



	std::cout << count << std::endl;


	clock_t end = clock();
	std::cout << "execution time" << end - start << std::endl;
	system("pause");


}

int checkroot(int i, std::vector<int> v)
{
	while (v[i] != i)
	{

		i = v[i];
	}

	return i;
}