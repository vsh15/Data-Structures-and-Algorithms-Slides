//Vishalsingh Hajeri
//Data Structure and Algorithm
//02/09/2016

#include<iostream>
#include<fstream>
#include<iomanip>
#include<string>

#include<vector>
#include<ctime>

int count =0;
bool connection(int, int, std::vector<int>& );

void main() {
	clock_t start = clock();
	std::vector<int> v;
	int p,q;
	
	std:: cout << "Assumption is made that maximum input number in your data sample is 8192" << std::endl;
	for (int i = 0; i <8192; i++)
	{
		 v.push_back(i);
	}
	std::cout << std::endl;


	std::string file;
	std::cout << "Please Enter the path of your data file\n" << "\t OR\n" << " You can keep your data file in the program folder and enter just the file name!" << std::endl;
	std::cin >> file;

	std::ifstream input(file);


		while (input >> p>>q)
	{

		//cout << p << "\t"<<q <<endl;
	bool check=	connection(p, q, v);

	if (check == false)
	{

		std::cout << p << "-" << q << std::endl;
		int id = v[p];

		for (int i = 0; i < v.size(); i++)
		{
			if (v[i] == id)
			{
				v[i] = v[q];

			}

		}
	}

	}

	

	std::cout << "Number of pairs Already connected = "<< count<<std::endl;
		

	clock_t end = clock();
	std::cout << "execution time : " << end - start << std::endl;
	system("pause");


}

	bool connection(int p, int q, std::vector<int>& v)
{
	
	if (v[p] == v[q])
	{
		std::cout<<p << " & " << q << " Already connected" << std::endl;
		count++;
		return true;
	}
	
	else 
		return false;



}