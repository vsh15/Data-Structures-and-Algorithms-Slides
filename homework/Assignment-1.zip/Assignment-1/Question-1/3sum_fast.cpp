//Vishalsingh Hajeri
//Data Structure and Algorithm
//02/09/2016


#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<ctime>
using namespace std;

//void quickSort(vector<int>&, int, int);

//int partition(vector<int>&, int, int);
void selectSort(vector<int> &arr, int n); //you can choose any method of sorting

int binarySearch(vector<int>, int, int, int);

void main() {

	clock_t start = clock();
	vector<int> v;
	int temp;
	int count = 0; 
	int z;
	
	string file;
	
	cout << "Please Enter the path of your data file\n"<<"\t OR\n"<<" You can keep your data file in the program folder and enter just the file name!" << endl;
	cin >> file;

	ifstream input(file);
	

	while (input >> temp)
	{

		v.push_back(temp);

	}

	
	selectSort(v, v.size());
	
	/*
	for (int i = 0; i < v.size(); i++)
	{
	cout << "\t" << v[i];
	}
	cout << endl;
	*/
	
	



	for (int i = 0; i < v.size(); i++)
	{
		
		for (int j = i + 1; j < v.size(); j++)
		{
			int element = binarySearch(v, (v[i]+v[j]), 0, (v.size()-1));

			if (element != -1)
			{
				
				cout << count + 1 << ")\t" << v[i] << "  (" << i << ") + " << v[j] << " (" << j << ") - " << v[i]+v[j] << " = 0" << endl;
				count++;
				 z = element+1;

				while ( z<v.size() && (v[z] == v[element]))
				{
					count++;
					z++;
									
				}

				int k = element-1;
				while (k >= 0 && v[k] == v[element] )
				{
					count++;
					k--;
					
				}

			}

		}
	}

	cout << endl << "Total Number of Three sum pairs: " << count << endl;
	clock_t end = clock();
	cout << "\n\n" << "Execution time is: " << end - start << endl;
	system("pause");


}


int binarySearch(vector<int> v,  int key,  int start,  int end)
{
	
	while (start<=end) {

		
		int mid = (start + end) / 2;

		if (v[mid] == key) {
			return mid;		//return the index of the element
		}


		else if (v[mid] > key)
			// Key is in lower half
			return binarySearch(v, key, start, mid - 1);
		else if (v[mid] < key)
			// Key is in upper half
			return binarySearch(v, key, mid + 1, end);

	}
	return -1; //return -1 if index not found 
	
}


void selectSort(vector<int> &arr, int n)
{
	
	int pos_min, temp;

	for (int i = 0; i < n - 1; i++)
	{
		pos_min = i;

		for (int j = i + 1; j < n; j++)
		{

			if (arr[j] < arr[pos_min])
				pos_min = j;
			
		}

		
		if (pos_min != i)
		{
			temp = arr[i];
			arr[i] = arr[pos_min];
			arr[pos_min] = temp;
		}
	}
}

/*

void quickSort(vector<int>& A, int p, int q)
{
	int r;
	if (p<q)
	{
		r = partition(A, p, q);
		quickSort(A, p, r);
		quickSort(A, r + 1, q);
	}
}


int partition(vector<int>& A, int p, int q)
{
	int x = A[p];
	int i = p;
	int j,temp;

	for (j = p + 1; j <= q; j++)
	{
		if (A[j] <= x)
		{
			i = i + 1;
			temp = A[i];
			A[i] = A[j];
			A[j] = temp;
			
		}

	}

	temp = A[i];
	A[i] = A[p];
	A[p] = temp;
	return i;
}*/