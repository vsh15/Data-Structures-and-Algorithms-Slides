//Vishalsingh Hajeri
//Data Structure and Algorithm
//02/09/2016



#include<iostream>
#include<fstream>
#include<iomanip>
#include<string>
#include<vector>
#include<ctime>
using namespace std;


void main() {
	clock_t start = clock();	//counter starts to measure execution time
	vector<int> v;
	int temp;
	string file;
	int count = 0;
	
	cout << "Please Enter the path of your data file OR you can keep your data file in the program folder and enter just the file name!" << endl;
	cin >> file;
	
	ifstream input(file);
	
	while (input >> temp)
	{

		v.push_back(temp);

	}

	/*
	for (int i = 0; i < v.size(); i++)
	{
	cout << "\t" << v[i];
	}
	cout << endl;
	*/
	
	

	for (int i = 0; i < v.size(); i++)
	{
		for (int j = i + 1; j < v.size(); j++)
		{
			for (int k = 0; k < v.size(); k++)
			{

				if (v[i] + v[j] - v[k] == 0 )
				{
					
					cout << count + 1 << ")\t" << v[i] << "  (" << i << ") + " << v[j] << " (" << j << ") - " << v[k] << " (" << k << ") = 0" << endl;
					count++;
				}

			}

		}
	}

	cout << endl << "Total Number of 3-sum Pairs : " << count << endl;

	clock_t end = clock();
	cout << "execution time : " << end - start << endl;
	system("pause");


}

