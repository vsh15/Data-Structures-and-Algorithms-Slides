//Vishalsingh Hajeri
//Data Structure and Algorithm
//02/09/2016

#include<iostream>
#include<iomanip>
#include<vector>

using namespace std;

void main() {
	int n;

	cout << "I am generating my own sample values using the rand() function" << endl;
	cout << "Enter the size of the array" << endl;
	cin >> n;
	
	
	
	vector<double> a;
	double min = 0;
	double max = 0;

	for (int i = 0; i < n; i++)
	{

		double x = (rand()-14.2746);
		a.push_back(x);
		
		if (x < min)
			min = x;
		if (x > max)
			max = x;

	}

	/*for (int i = 0; i < a.size(); i++)
	{
		if (a[i] < min)
			min = a[i];
		if (a[i] > max)
			max = a[i];
	}
	*/
	double temp;
	temp = max - min;

	if (temp < 0)
	{
		temp = temp*-1;
	}
	cout << "min :" << min << "\t max:" << max << endl;
	cout << "difference: " << temp << endl;

	system("pause");
}