Question 1&2]
1. I have submitted a single cpp file which covers question 1 and 2.
2.There is a global variable max, which defines the input size for the program.default=1500
3. I am shuffling the array by calling knuth shuffle function.
4. Outpus is an inorder traversal of the tree and number of nodes and average path length is displayed.

Question 3]
1.There is a global variable max, which defines the input size for the program.default=1000
2. For each input size (% of red count) is averaged over 100 trials (increamenting j, upto 100)
3. I count red nodes by doing an inorder traversal 


Question-4]
There is a global variable max, which defines the input size for the program.
variable 'j' defined in main() is used for number of trials. Edit ' while(j!=1000)' to change the trial runs.
I assign depth to every node after complete tree is created by using assigndepth()
	
1)I am calculating average path length in every iteration 
2) Mean of average path length is calculated and displayed at the end
3) Standard deviation is calculated in the Excel sheet(or it could be calculated in the program itself by mainining a separate vector<double>)