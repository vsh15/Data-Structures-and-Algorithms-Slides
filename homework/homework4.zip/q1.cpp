//Vishalsingh Hajeri
//Data Structures and Algorithm
//03/29/2016

#include<iostream>
#include<vector>
#include<fstream>
#include<string>

#define nullvalue -1

using namespace std;

int tempDepth = 0;
float Totalnodes = 0.0;

const int max = 1500;

void swap(int *v, int i, int j) {
	int temp;
	temp = v[j];
	v[j] = v[i];
	v[i] = temp;

};

void knuth_shuffle(int *v, int len) {

	for (int i = 1; i < len; i++)
	{
		int x = rand() % i;

		swap(v, i, x);

	}
};




struct tree_23
{
	int data1, data2;
	int depth;
	tree_23 *left, *middle, *right;
};


tree_23 *makeNode(int data)
{
	tree_23 *newNode = new tree_23;
	newNode->data1 = data;
	newNode->data2 =nullvalue;
	newNode->left = newNode->middle = newNode->right = NULL;
	newNode->depth = tempDepth + 1;
	Totalnodes++;
	return newNode;
}


void insertNode(int data, tree_23 *&root)
{
	if (root == NULL)
	{
		root = makeNode(data);
	}

	//check data2 variable
	else if (root->data2 ==nullvalue)
	{
		if (data > root->data1)
		{
			root->data2 = data;
		}
		else if (data < root->data1)
		{
			root->data2 = root->data1;
			root->data1 = data;
		}
		else
		{		
		}
	}

	//if root is full, then recur down
	else if (root->data2 !=nullvalue)
	{
		if (data < root->data1)
		{
			tempDepth = root->depth;
			insertNode(data, root->left);
		}
		else if (data > root->data2)
		{
			tempDepth = root->depth;
			insertNode(data, root->right);
		}
		else if (data > root->data1 && data < root->data2)
		{
			tempDepth = root->depth;
			insertNode(data, root->middle);
		}
		else
		{	
		}
		
	}
}


void printInorder(tree_23 *&root)
{
	if (root == NULL)
		return;


	if (root->left == NULL && root->middle == NULL && root->right == NULL)
	{
		cout << root->data1 << "\t";
		if (root->data2 !=nullvalue)
			cout << root->data2 << "\t";
	}



	else
	{
		printInorder(root->left);

		cout << root->data1 << "\t";
		
		printInorder(root->middle);

		if (root->data2 !=nullvalue)
			cout << root->data2 << "\t";

		printInorder(root->right);
	}
}


int Calculatedepth(tree_23 *&root, int totalDepth)
{
	
	if (root == NULL)
		return 0;

	if (root->left == NULL && root->middle == NULL && root->right == NULL)
		totalDepth = root->depth;
	else
	{
		totalDepth = root->depth + Calculatedepth(root->left, totalDepth) + Calculatedepth(root->middle, totalDepth) + Calculatedepth(root->right, totalDepth);
		
	}
	return totalDepth;
}


int main()
{
	tree_23 *root;
	root = NULL;
	int totalDepth;
	float avgDepth;
	
	

	int arr[::max];

	//generating input data
	for (int i = 0; i < ::max; i++)
	{
		arr[i] = i;
	}

	knuth_shuffle(arr, ::max);

	//generating 2-3 tree
	for (int i = 0; i < ::max; i++)
	{
				
		insertNode(arr[i], root);
	}


	cout << "Inorder Traversal : \n";
	printInorder(root);

	//return internal path length
	totalDepth = Calculatedepth(root, 0);
	avgDepth = totalDepth / Totalnodes;
	
	
	cout << "\n Total Nodes = "<<Totalnodes << "\nInternal path length = " << avgDepth << endl;


	system("pause");
	return 0;
}

