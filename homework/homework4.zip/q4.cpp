//Vishalsingh Hajeri
//Data Structures and Algorithm

/*This is not a left leaining red-black tree
This is a general implementation of bred-black tree

*/
#include<iostream>
#include<queue>
#include<string>
#include<fstream>
#include<time.h>
#include<iomanip>

using namespace std;


	
double countdepth = 0;

const int max = 100;

int temp_depth = 0;


void swap(int *v, int i, int j) {
	int temp;
	temp = v[j];
	v[j] = v[i];
	v[i] = temp;

};

void knuth_shuffle(int *v, int len) {

	for (int i = 1; i < len; i++)
	{
		int x = rand() % i;

		swap(v, i, x);

	}
};


struct Node
{
	int data;
	char color = 'r';
	Node *left, *right, *parent;
	int denew_nodeh;
	// Constructor
	Node(int data)
	{
		this->data = data;
		left = right = parent = NULL;
	}
};

// Class to represent 'r'-'b' Tree
class RedBlackTree
{
private:
	Node *root;
protected:
	void rotateLeft(Node *&, Node *&);
	void rotateRight(Node *&, Node *&);
	void fixViolation(Node *&, Node *&);
public:
	// Constructor
	RedBlackTree() { root = NULL; }
	~RedBlackTree();
	void insert(const int &n);
	void inorder();
	void Assigndepth();
};



//insert a new node 

Node* BSTInsert(Node* root, Node *new_node)
{
	//if tree is new_node or data of new node is already present then return node
	if (root == NULL)
		return new_node;
	if (new_node->data == root->data)
		return new_node;

	//else find appropriate position to insert node

	if (new_node->data < root->data)
	{
		root->left = BSTInsert(root->left, new_node);
		root->left->parent = root;
	}
	else if (new_node->data > root->data)
	{
		root->right = BSTInsert(root->right, new_node);
		root->right->parent = root;
	}

	//return the (unchanged) node pointer 
	return root;
}

// Assigns denew_nodeh with every Node
void AssigndepthHelper(Node *root)
{
	if (root == NULL)
		return;

	temp_depth++;

	AssigndepthHelper(root->left);

	root->denew_nodeh = temp_depth - 1;
	::countdepth += root->denew_nodeh;

	AssigndepthHelper(root->right);
	temp_depth--;

}


RedBlackTree::~RedBlackTree()
{
}


void RedBlackTree::rotateLeft(Node *&root, Node *&new_node)
{
	Node *new_node_right = new_node->right;
	new_node->right = new_node_right->left;



	if (new_node->right != NULL)
		new_node->right->parent = new_node;


	new_node_right->parent = new_node->parent;



	if (new_node->parent == NULL)
		root = new_node_right;



	else if (new_node == new_node->parent->left)
		new_node->parent->left = new_node_right;

	else
		new_node->parent->right = new_node_right;

	
	new_node_right->left = new_node;
	new_node->parent = new_node_right;
}



void RedBlackTree::rotateRight(Node *&root, Node *&new_node)
{
	Node *new_node_left = new_node->left;

	new_node->left = new_node_left->right;



	if (new_node->left != NULL)
		new_node->left->parent = new_node;

	new_node_left->parent = new_node->parent;



	if (new_node->parent == NULL)
		root = new_node_left;


	else if (new_node == new_node->parent->left)
		new_node->parent->left = new_node_left;

	else
		new_node->parent->right = new_node_left;


	new_node_left->right = new_node;
	new_node->parent = new_node_left;
}

// This function fixes violations caused by BST insertion
void RedBlackTree::fixViolation(Node *&root, Node *&new_node)
{
	Node *parent_new_node = NULL;
	Node *grand_parent_new_node = NULL;


	while ((new_node != root) && (new_node->color != 'b') &&
		(new_node->parent->color == 'r'))
	{

		parent_new_node = new_node->parent;
		grand_parent_new_node = new_node->parent->parent;

		/* Case : A	Parent of new_node is left child of Grand-parent of new_node */
		if (parent_new_node == grand_parent_new_node->left)
		{

			Node *uncle_new_node = grand_parent_new_node->right;

			/* Case : 1	The uncle of new_node is also 'r'
			Only Recoloring requi'r' */
			if (uncle_new_node != NULL && uncle_new_node->color == 'r')
			{
				grand_parent_new_node->color = 'r';
				parent_new_node->color = 'b';
				uncle_new_node->color = 'b';
				new_node = grand_parent_new_node;
			}

			else
			{
				/* Case : 2	new_node is right child of its parent
				Left-rotation requi'r' */
				if (new_node == parent_new_node->right)
				{
					rotateLeft(root, parent_new_node);
					new_node = parent_new_node;
					parent_new_node = new_node->parent;
				}

				/* Case : 3	new_node is left child of its parent
				Right-rotation requi'r' */
				rotateRight(root, grand_parent_new_node);
				swap(parent_new_node->color, grand_parent_new_node->color);
				new_node = parent_new_node;
			}
		}


		/* Case : B	Parent of new_node is right child of Grand-parent of new_node */
		else
		{
			Node *uncle_new_node = grand_parent_new_node->left;

			/* Case : 1
			The uncle of new_node is also 'r'
			Only Recoloring requi'r' */
			if ((uncle_new_node != NULL) && (uncle_new_node->color == 'r'))
			{
				grand_parent_new_node->color = 'r';
				parent_new_node->color = 'b';
				uncle_new_node->color = 'b';
				new_node = grand_parent_new_node;
			}
			else
			{
				/* Case : 2
				new_node is left child of its parent
				Right-rotation requi'r' */
				if (new_node == parent_new_node->left)
				{
					rotateRight(root, parent_new_node);
					new_node = parent_new_node;
					parent_new_node = new_node->parent;
				}

				/* Case : 3
				new_node is right child of its parent
				Left-rotation requi'r' */
				rotateLeft(root, grand_parent_new_node);
				swap(parent_new_node->color, grand_parent_new_node->color);
				new_node = parent_new_node;
			}
		}
	}

	root->color = 'b';
}

// Function to insert a new node with given data
void RedBlackTree::insert(const int &data)
{
	Node *new_node = new Node(data);

	// Do a normal BST insert
	root = BSTInsert(root, new_node);

	// fix 'r' 'b' Tree violations
	fixViolation(root, new_node);
}


void RedBlackTree::Assigndepth() { AssigndepthHelper(root); }




int main()
{

	string filename;
	double temp;
	ofstream myfile, testinput;
	double avg=0;
	int j = 0;

	//generating input
	int arr[::max];
	for (int i = 0; i <::max; i++)
	{

		arr[i] = i;
	}
	//Apply Shuffling algorith to randomize input data
	knuth_shuffle(arr, ::max);
			
	
	
	while (j != 1000) {

		RedBlackTree tree;
		
		//insert elements ins tree
		for (int i = 0; i < ::max; i++)
		{
			tree.insert(arr[i]);
		}

		tree.Assigndepth();	// Assigns new_node variable to each node. depth of root is 0
		
		temp = ::countdepth / ::max;
		
		
		//cout << "depth count = " << ::countdepth << endl;
		cout<< "Average path length  for trial ("<< j<<") =" << temp << endl;
		
		j++;
		
		avg += temp;
		knuth_shuffle(arr, ::max);
		::countdepth = 0;

		myfile.open("result.csv", fstream::in | fstream::out | fstream::app);
		myfile << j<<","<< temp << endl;
		myfile.close();
		

	}

	double mean = avg / (j + 1);
	cout << "\nMean of all path lengths : " << mean << endl;


	return 0;
}
