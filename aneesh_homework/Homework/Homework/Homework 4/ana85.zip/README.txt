Q2)
	a. Compile and run the code with a command line argument of filename, along with extension (ex - input.txt)
	b. Number of nodes and average depth is printed on the console
	c. Average depth is written to the output file called out.txt

Q3)
	a. Compile and run without command line arguments
	b. Enter data size when prompted (1024, 2048, 4096, 8192, etc.)
	c. Enter output file name when prompted, along with extension (ex - out.txt)
	d. Percentages of Red Nodes are printed on console
	e. Percentages of Red Nodes are written inside the file for all 100 trials

Q4) 
	a. Compile and run without command line arguments
	b. Enter data size when prompted (1024, 2048, 4096, 8192, etc.)
	c. Enter output file name when prompted, along with extension (ex - out.txt)
	d. Total Number of Nodes and Average Path Lengths are printed on console
	e. Average Path Lengths are written inside the file for all 1000 trials