Q1)
	1. Give Command Line Argument while running the code as - filename.txt
		- Keep the input file at the same location as the code
	2. Compile and Run the Code
	3. Result in terms of whether cycle exists or not is printed on the console
	4. Same result is also written to the output file out.txt

Q2 a and b)
	1. Give Command Line Argument while running the code as - filename.txt
		- Keep the input file at the same location as the code
	2. Compile and Run the Code
	3. Edges included in the MST are printed along with their costs
	4. Same result is also written to the output file out.txt  

Q5 a and b)
	1. Give Command Line Argument while running the code as - filename.txt
		- Keep the input file at the same location as the code
	2. Compile and Run the Code
	3. Nodes traversed in DFS/BFS exploration are printed in that order on the console	

Q6)
	1. Give Command Line Argument while running the code as - filename.txt
		- Keep the input file at the same location as the code
	2. Compile and Run the Code
	3. Distances of all nodes from the source are printed to the console
	4. Same result is also written to the output file out.txt

